Set-ExecutionPolicy RemoteSigned -Scope Process

#ls .\src_original | %{ .\module\export_vba_source.vbs $_.FullName,"C:\Users\yasuhisa-sasahara\Documents\dev\src_original_text" }
ls .\src_modify | %{ .\module\export_vba_source.vbs $_.FullName,"C:\Users\yasuhisa-sasahara\Documents\dev\src_modify_text" }
